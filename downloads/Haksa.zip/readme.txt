* 필요 환경
1. JDK 11
2. Oracle 21c XE
3. OJDBC 11 사용
4. localhost_haein.db 의 테이블과 데이터 추가
user name: haein
use pwd: shinystar